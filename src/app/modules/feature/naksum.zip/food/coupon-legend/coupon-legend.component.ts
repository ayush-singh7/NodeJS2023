import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coupon-legend',
  templateUrl: './coupon-legend.component.html',
  styleUrls: ['./coupon-legend.component.scss']
})
export class CouponLegendComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
