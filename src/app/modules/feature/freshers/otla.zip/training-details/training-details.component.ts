import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-training-details',
  templateUrl: './training-details.component.html',
  styleUrls: ['./training-details.component.scss']
})
export class TrainingDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
