import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomCarouselComponent } from './custom-carousel.component';



@NgModule({
  declarations: [
    CustomCarouselComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    CustomCarouselComponent
  ]
})
export class CustomCarouselModule { }
