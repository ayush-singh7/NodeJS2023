import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-carousel',
  templateUrl: './custom-carousel.component.html',
  styleUrls: ['./custom-carousel.component.scss']
})
export class CustomCarouselComponent implements OnInit {
  // private LOGO = require("./assets/logo.png");

  constructor() { }

  @Input() buttonsExist!:boolean;
  @Input() imageList!:any;
  @Input() headingData:any
  ngOnInit(): void {
    setInterval(()=>{
      this.onPrevClick(1)
    }, 2500);

    
  }
  selectedIndex:number = 0;
  onPrevClick(count:number){

    this.selectedIndex = this.selectedIndex + count
    if(this.selectedIndex == -1){
      this.selectedIndex = this.imageList.length - 1
    }
    if(this.selectedIndex == this.imageList.length){
      this.selectedIndex = 0
    }


  }
}
