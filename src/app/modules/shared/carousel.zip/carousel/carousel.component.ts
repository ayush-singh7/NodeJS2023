import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss']
})
export class CarouselComponent implements OnInit {

  constructor() { }
  @Input() buttonsExist!: boolean;
  @Input() parentData!: any;
  @Input() imageList!:any;

  

  ngOnInit(): void {
    console.log(this.imageList,"IML");
    
    // setInterval(()=>{
    //   this.changeSlide(true)
    // },this.delay)
  }

  current = 0;
  delay = 3000; //ms
  prevPress(){
    this.changeSlide(true); //back
    // this.restart();
  }
  nextPress(){
    this.changeSlide(false); //forward
    // this.restart();
  }
   changeSlide(next:boolean) {

    const slides = document.querySelector(".slides") as HTMLElement
    const slidesCount = slides.childElementCount;
    const maxLeft = (slidesCount - 1) * 100 * -1;
    
    if (next) { 
      let temp = this.current > maxLeft ? -100 : this.current * -1;
      this.current += temp;
    } else {
      this.current = this.current < 0 ? this.current + 100 : maxLeft;
    }
    
    slides.style.left = this.current + "%";
  }
  restart(){
    
  }


}
